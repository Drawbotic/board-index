# Arduino-SAMD
This is the SensiLab SAMD Core for Arduino. It contains all of the required supporting files and configuration for uploading Arduino sketchings to SAMD based boards made in SensiLab.

It is a modified version of the SAMD Core created by MattairTech (https://github.com/mattairtech/ArduinoCore-samd), thanks to them for the initial work moving the offical Arduino Core over to more SAMD variants.

The included bootloader is a build of the SensiLab fork of the UF2 bootloader. More details can be found here: https://github.com/SensiLab/uf2-samdx1